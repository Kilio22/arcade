/*
** EPITECH PROJECT, 2020
** OOP_arcade_2019
** File description:
** arcade
*/

#ifndef ARCADE_H_
#define ARCADE_H_

#define ARCADE_SUCCESS 0
#define ARCADE_FAILURE 84

#define ARCADE_LIB_PATH "./lib/"
#define ARCADE_GAMES_PATH "./games/"

#endif /* !ARCADE_H_ */
