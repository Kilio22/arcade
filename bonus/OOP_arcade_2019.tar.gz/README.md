# Arcade

Project carried out in collaboration with the following group leaders:

- _kylian.balan@epitech.eu_
- **thomas1.bastien@epitech.eu**
- paulic1.killian@epitech.eu
- remi.balbous@epitech.eu
- philippe.loctaux@epitech.eu
- ghassane.sebai@epitech.eu
- yann.peu@epitech.eu
- kevin.huet@epitech.eu
- peter.bessone@epitech.eu
- louis.girard@epitech.eu
- eliott.palueau@epitech.eu
- yoann.le-colleter@epitech.eu
